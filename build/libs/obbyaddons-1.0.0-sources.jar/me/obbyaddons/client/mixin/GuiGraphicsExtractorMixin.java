package me.obbyaddons.client.mixin;

import me.obbyaddons.client.features.dungeon.terminator.TerminatorOverlayRenderer;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiGraphicsExtractor.class)
public abstract class GuiGraphicsExtractorMixin {

    @Inject(
            method = "itemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V",
            at = @At("TAIL")
    )
    private void obbyaddons$renderTerminatorOverlay(
            Font font,
            ItemStack stack,
            int x,
            int y,
            String countText,
            CallbackInfo ci
    ) {

        TerminatorOverlayRenderer.render(
                (GuiGraphicsExtractor) (Object) this,
                stack,
                x,
                y
        );
    }
}